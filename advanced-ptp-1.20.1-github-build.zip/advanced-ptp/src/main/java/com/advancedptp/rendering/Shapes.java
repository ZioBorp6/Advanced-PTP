package com.advancedptp.rendering;

import com.advancedptp.config.LineStyle;
import com.advancedptp.physics.Trajectory;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;

/** Geometry built on top of {@link Batch}: styled polylines, boxes, impact markers. */
final class Shapes {
    private Shapes() {}

    /** Draws the flight path as a solid, dashed or dotted polyline. */
    static void polyline(Trajectory t, LineStyle style, int argb) {
        if (style == LineStyle.SOLID) {
            for (int i = 0; i < t.count - 1; i++) {
                Batch.line(t.x[i], t.y[i], t.z[i], t.x[i + 1], t.y[i + 1], t.z[i + 1], argb);
            }
            return;
        }
        boolean drawing = true;
        double remaining = style.on;
        for (int i = 0; i < t.count - 1; i++) {
            double ax = t.x[i], ay = t.y[i], az = t.z[i];
            double dx = t.x[i + 1] - ax, dy = t.y[i + 1] - ay, dz = t.z[i + 1] - az;
            double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (len < 1.0e-9) {
                continue;
            }
            double ux = dx / len, uy = dy / len, uz = dz / len;
            double pos = 0.0;
            while (pos < len) {
                double step = Math.min(remaining, len - pos);
                if (drawing) {
                    Batch.line(ax + ux * pos, ay + uy * pos, az + uz * pos,
                        ax + ux * (pos + step), ay + uy * (pos + step), az + uz * (pos + step), argb);
                }
                pos += step;
                remaining -= step;
                if (remaining <= 1.0e-9) {
                    drawing = !drawing;
                    remaining = drawing ? style.on : style.off;
                }
            }
        }
    }

    /** Impact indicator: a square with diagonals lying on the hit face, or a 3-axis cross in mid-air/on entities. */
    static void impactMarker(double x, double y, double z, Direction side, boolean onFace, int argb) {
        double s = 0.25;
        if (!onFace) {
            Batch.line(x - s, y, z, x + s, y, z, argb);
            Batch.line(x, y - s, z, x, y + s, z, argb);
            Batch.line(x, y, z - s, x, y, z + s, argb);
            return;
        }
        double off = 0.01;
        x += side.getOffsetX() * off;
        y += side.getOffsetY() * off;
        z += side.getOffsetZ() * off;
        switch (side.getAxis()) {
            case X -> face(x, y, z, 0, 1, 0, 0, 0, 1, s, argb);
            case Y -> face(x, y, z, 1, 0, 0, 0, 0, 1, s, argb);
            default -> face(x, y, z, 1, 0, 0, 0, 1, 0, s, argb);
        }
    }

    private static void face(double x, double y, double z, double ux, double uy, double uz,
                             double vx, double vy, double vz, double s, int argb) {
        double ax = x - (ux + vx) * s, ay = y - (uy + vy) * s, az = z - (uz + vz) * s; // (-,-)
        double bx = x + (ux - vx) * s, by = y + (uy - vy) * s, bz = z + (uz - vz) * s; // (+,-)
        double cx = x + (ux + vx) * s, cy = y + (uy + vy) * s, cz = z + (uz + vz) * s; // (+,+)
        double dx = x + (vx - ux) * s, dy = y + (vy - uy) * s, dz = z + (vz - uz) * s; // (-,+)
        Batch.line(ax, ay, az, bx, by, bz, argb);
        Batch.line(bx, by, bz, cx, cy, cz, argb);
        Batch.line(cx, cy, cz, dx, dy, dz, argb);
        Batch.line(dx, dy, dz, ax, ay, az, argb);
        Batch.line(ax, ay, az, cx, cy, cz, argb);
        Batch.line(bx, by, bz, dx, dy, dz, argb);
    }

    static void boxOutline(Box b, int argb) {
        double x1 = b.minX, y1 = b.minY, z1 = b.minZ, x2 = b.maxX, y2 = b.maxY, z2 = b.maxZ;
        Batch.line(x1, y1, z1, x2, y1, z1, argb);
        Batch.line(x1, y1, z2, x2, y1, z2, argb);
        Batch.line(x1, y2, z1, x2, y2, z1, argb);
        Batch.line(x1, y2, z2, x2, y2, z2, argb);
        Batch.line(x1, y1, z1, x1, y2, z1, argb);
        Batch.line(x2, y1, z1, x2, y2, z1, argb);
        Batch.line(x1, y1, z2, x1, y2, z2, argb);
        Batch.line(x2, y1, z2, x2, y2, z2, argb);
        Batch.line(x1, y1, z1, x1, y1, z2, argb);
        Batch.line(x2, y1, z1, x2, y1, z2, argb);
        Batch.line(x1, y2, z1, x1, y2, z2, argb);
        Batch.line(x2, y2, z1, x2, y2, z2, argb);
    }

    static void boxFill(Box b, int argb) {
        double x1 = b.minX, y1 = b.minY, z1 = b.minZ, x2 = b.maxX, y2 = b.maxY, z2 = b.maxZ;
        Batch.quad(x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2, argb); // bottom
        Batch.quad(x1, y2, z1, x1, y2, z2, x2, y2, z2, x2, y2, z1, argb); // top
        Batch.quad(x1, y1, z1, x1, y2, z1, x2, y2, z1, x2, y1, z1, argb); // north
        Batch.quad(x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2, argb); // south
        Batch.quad(x1, y1, z1, x1, y1, z2, x1, y2, z2, x1, y2, z1, argb); // west
        Batch.quad(x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2, argb); // east
    }

    /** Fills the face of the block that was hit. */
    static void blockFace(int bx, int by, int bz, Direction side, int argb) {
        double e = 0.003;
        double x1 = bx, y1 = by, z1 = bz, x2 = bx + 1, y2 = by + 1, z2 = bz + 1;
        switch (side) {
            case UP -> Batch.quad(x1, y2 + e, z1, x1, y2 + e, z2, x2, y2 + e, z2, x2, y2 + e, z1, argb);
            case DOWN -> Batch.quad(x1, y1 - e, z1, x2, y1 - e, z1, x2, y1 - e, z2, x1, y1 - e, z2, argb);
            case NORTH -> Batch.quad(x1, y1, z1 - e, x1, y2, z1 - e, x2, y2, z1 - e, x2, y1, z1 - e, argb);
            case SOUTH -> Batch.quad(x1, y1, z2 + e, x2, y1, z2 + e, x2, y2, z2 + e, x1, y2, z2 + e, argb);
            case WEST -> Batch.quad(x1 - e, y1, z1, x1 - e, y1, z2, x1 - e, y2, z2, x1 - e, y2, z1, argb);
            case EAST -> Batch.quad(x2 + e, y1, z1, x2 + e, y2, z1, x2 + e, y2, z2, x2 + e, y1, z2, argb);
        }
    }
}
