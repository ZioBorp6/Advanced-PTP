package com.advancedptp.rendering;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Tiny immediate-mode helper around the shared Tessellator buffer. All coordinates passed in are
 * world coordinates; the camera offset is subtracted here. Static state keeps it allocation-free.
 */
final class Batch {
    private static BufferBuilder bb;
    private static Matrix4f pm;
    private static Matrix3f nm;
    private static double cx, cy, cz;
    private static int vertices;

    private Batch() {}

    static void beginLines(Matrix4f positionMatrix, Matrix3f normalMatrix, Vec3d cam, float width) {
        pm = positionMatrix;
        nm = normalMatrix;
        cx = cam.x;
        cy = cam.y;
        cz = cam.z;
        vertices = 0;
        RenderSystem.setShader(GameRenderer::getRenderTypeLinesProgram);
        RenderSystem.lineWidth(width);
        bb = Tessellator.getInstance().getBuffer();
        bb.begin(VertexFormat.DrawMode.LINES, VertexFormats.LINES);
    }

    static void beginQuads(Matrix4f positionMatrix, Vec3d cam) {
        pm = positionMatrix;
        cx = cam.x;
        cy = cam.y;
        cz = cam.z;
        vertices = 0;
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        bb = Tessellator.getInstance().getBuffer();
        bb.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
    }

    static void end() {
        // BufferBuilder must always be ended once begun; drawing an empty buffer is a no-op.
        BufferRenderer.drawWithGlobalProgram(bb.end());
        bb = null;
    }

    static boolean isEmpty() {
        return vertices == 0;
    }

    /** Line segment; the normal attribute carries the direction, as the vanilla line shader expects. */
    static void line(double x1, double y1, double z1, double x2, double y2, double z2, int argb) {
        double dx = x2 - x1, dy = y2 - y1, dz = z2 - z1;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1.0e-6) {
            return;
        }
        float nx = (float) (dx / len), ny = (float) (dy / len), nz = (float) (dz / len);
        int a = argb >>> 24, r = (argb >> 16) & 255, g = (argb >> 8) & 255, b = argb & 255;
        bb.vertex(pm, (float) (x1 - cx), (float) (y1 - cy), (float) (z1 - cz)).color(r, g, b, a).normal(nm, nx, ny, nz).next();
        bb.vertex(pm, (float) (x2 - cx), (float) (y2 - cy), (float) (z2 - cz)).color(r, g, b, a).normal(nm, nx, ny, nz).next();
        vertices += 2;
    }

    static void quadVertex(double x, double y, double z, int argb) {
        int a = argb >>> 24, r = (argb >> 16) & 255, g = (argb >> 8) & 255, b = argb & 255;
        bb.vertex(pm, (float) (x - cx), (float) (y - cy), (float) (z - cz)).color(r, g, b, a).next();
        vertices++;
    }

    static void quad(double x1, double y1, double z1, double x2, double y2, double z2,
                     double x3, double y3, double z3, double x4, double y4, double z4, int argb) {
        quadVertex(x1, y1, z1, argb);
        quadVertex(x2, y2, z2, argb);
        quadVertex(x3, y3, z3, argb);
        quadVertex(x4, y4, z4, argb);
    }
}
