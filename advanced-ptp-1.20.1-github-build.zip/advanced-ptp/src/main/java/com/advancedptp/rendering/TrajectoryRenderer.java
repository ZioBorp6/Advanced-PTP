package com.advancedptp.rendering;

import com.advancedptp.config.PtpConfig;
import com.advancedptp.physics.PredictionManager;
import com.advancedptp.physics.PredictionSlot;
import com.advancedptp.physics.Trajectory;
import com.advancedptp.util.ColorUtil;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** Draws all active predictions at the end of world rendering (WorldRenderEvents.LAST). */
public final class TrajectoryRenderer {
    private static final float OUTLINE_WIDTH = 2.5f;

    private TrajectoryRenderer() {}

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        PtpConfig cfg = PtpConfig.get();
        if (!cfg.enabled || mc.player == null || mc.world == null || mc.player.isSpectator()) {
            return;
        }

        float tickDelta = ctx.tickDelta();
        PredictionManager.update(mc, tickDelta);

        PredictionSlot[] slots = {PredictionManager.MAIN, PredictionManager.OFF, PredictionManager.DROP};
        boolean any = false;
        for (PredictionSlot s : slots) {
            any |= s.active && s.trajectory.count > 1;
        }
        if (!any) {
            return;
        }

        MatrixStack.Entry entry = ctx.matrixStack().peek();
        Matrix4f pm = entry.getPositionMatrix();
        Matrix3f nm = entry.getNormalMatrix();
        Vec3d cam = ctx.camera().getPos();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        if (cfg.seeThroughBlocks) {
            RenderSystem.disableDepthTest();
        } else {
            RenderSystem.enableDepthTest();
        }

        try {
            // Pass 1: translucent fills for the highlighted target.
            if (cfg.highlightingEnabled) {
                int color = ColorUtil.argb(cfg.highlightColor, cfg.highlightOpacity);
                Batch.beginQuads(pm, cam);
                for (PredictionSlot s : slots) {
                    if (s.active && s.trajectory.count > 1) {
                        highlight(s.trajectory, tickDelta, mc, color);
                    }
                }
                Batch.end();
            }

            // Pass 2: the trajectory itself and impact marker.
            int lineColor = ColorUtil.argb(cfg.trajectoryColor, cfg.trajectoryOpacity);
            Batch.beginLines(pm, nm, cam, cfg.lineThickness);
            for (PredictionSlot s : slots) {
                if (!s.active || s.trajectory.count < 2) {
                    continue;
                }
                Trajectory t = s.trajectory;
                Shapes.polyline(t, cfg.lineStyle, lineColor);
                switch (t.hitType) {
                    case BLOCK -> Shapes.impactMarker(t.hitPos.x, t.hitPos.y, t.hitPos.z, t.hitSide, true, lineColor);
                    case ENTITY, WATER -> Shapes.impactMarker(t.hitPos.x, t.hitPos.y, t.hitPos.z, t.hitSide, false, lineColor);
                    default -> {
                        int last = t.count - 1;
                        Shapes.impactMarker(t.x[last], t.y[last], t.z[last], t.hitSide, false, lineColor);
                    }
                }
            }
            Batch.end();

            // Pass 3: outline around the entity that would be hit.
            if (cfg.outliningEnabled) {
                int color = ColorUtil.argb(cfg.outlineColor, cfg.outlineOpacity);
                Batch.beginLines(pm, nm, cam, OUTLINE_WIDTH);
                for (PredictionSlot s : slots) {
                    if (s.active && s.trajectory.hitType == Trajectory.HitType.ENTITY) {
                        Box box = entityBox(s.trajectory.hitEntity, tickDelta, mc);
                        if (box != null) {
                            Shapes.boxOutline(box, color);
                        }
                    }
                }
                Batch.end();
            }
        } finally {
            RenderSystem.lineWidth(1.0f);
            RenderSystem.depthMask(true);
            RenderSystem.enableDepthTest();
            RenderSystem.enableCull();
            RenderSystem.disableBlend();
        }
    }

    private static void highlight(Trajectory t, float tickDelta, MinecraftClient mc, int color) {
        switch (t.hitType) {
            case ENTITY -> {
                Box box = entityBox(t.hitEntity, tickDelta, mc);
                if (box != null) {
                    Shapes.boxFill(box, color);
                }
            }
            case BLOCK -> Shapes.blockFace(t.hitBlock.getX(), t.hitBlock.getY(), t.hitBlock.getZ(), t.hitSide, color);
            default -> { }
        }
    }

    /** Entity bounding box shifted to its interpolated render position; null if it no longer exists here. */
    private static Box entityBox(Entity e, float tickDelta, MinecraftClient mc) {
        if (e == null || e.isRemoved() || e.getWorld() != mc.world) {
            return null;
        }
        Vec3d lerped = e.getLerpedPos(tickDelta);
        return e.getBoundingBox()
            .offset(lerped.x - e.getX(), lerped.y - e.getY(), lerped.z - e.getZ())
            .expand(0.002);
    }
}
