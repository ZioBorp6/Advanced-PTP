package com.advancedptp.keybind;

import com.advancedptp.config.PtpConfig;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class Keybinds {
    private static final String CATEGORY = "key.categories.advancedptp";

    private static KeyBinding toggleAll;
    private static KeyBinding toggleOutline;
    private static KeyBinding toggleHighlight;
    private static KeyBinding toggleDrop;

    private Keybinds() {}

    public static void register() {
        toggleAll = reg("toggle_all");
        toggleOutline = reg("toggle_outline");
        toggleHighlight = reg("toggle_highlight");
        toggleDrop = reg("toggle_drop");
    }

    private static KeyBinding reg(String name) {
        // Unbound by default so nothing conflicts; players pick keys in Options > Controls.
        return KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.advancedptp." + name, InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, CATEGORY));
    }

    public static void tick(MinecraftClient client) {
        PtpConfig c = PtpConfig.get();
        boolean changed = false;
        while (toggleAll.wasPressed()) {
            c.enabled = !c.enabled;
            notify(client, "toggle_all", c.enabled);
            changed = true;
        }
        while (toggleOutline.wasPressed()) {
            c.outliningEnabled = !c.outliningEnabled;
            notify(client, "toggle_outline", c.outliningEnabled);
            changed = true;
        }
        while (toggleHighlight.wasPressed()) {
            c.highlightingEnabled = !c.highlightingEnabled;
            notify(client, "toggle_highlight", c.highlightingEnabled);
            changed = true;
        }
        while (toggleDrop.wasPressed()) {
            c.dropTrajectoryEnabled = !c.dropTrajectoryEnabled;
            notify(client, "toggle_drop", c.dropTrajectoryEnabled);
            changed = true;
        }
        if (changed) {
            PtpConfig.save();
        }
    }

    private static void notify(MinecraftClient client, String key, boolean on) {
        if (client.player != null) {
            client.player.sendMessage(
                Text.translatable("advancedptp.message." + key, Text.translatable(on ? "options.on" : "options.off")), true);
        }
    }
}
