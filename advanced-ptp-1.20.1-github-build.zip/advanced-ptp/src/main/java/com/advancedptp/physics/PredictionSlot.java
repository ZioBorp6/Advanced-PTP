package com.advancedptp.physics;

import com.advancedptp.projectile.LaunchProfile;
import net.minecraft.world.World;

/** One independent prediction (main hand, offhand or item drop) plus its cache key. */
public final class PredictionSlot {
    public final Trajectory trajectory = new Trajectory();
    public boolean active;

    private boolean valid;
    private LaunchProfile profile;
    private World world;
    private int tick;
    private double kpx, kpy, kpz, kvx, kvy, kvz;

    /** True when the stored result is still good for these inputs. */
    boolean isFresh(LaunchProfile pr, LaunchState s, World w, int nowTick, int maxAgeTicks) {
        if (!valid || profile != pr && !pr.equals(profile) || world != w || nowTick - tick >= maxAgeTicks) {
            return false;
        }
        if (trajectory.hitEntity != null && trajectory.hitEntity.isRemoved()) {
            return false;
        }
        return kpx == s.px && kpy == s.py && kpz == s.pz && kvx == s.vx && kvy == s.vy && kvz == s.vz;
    }

    void store(LaunchProfile pr, LaunchState s, World w, int nowTick) {
        valid = true;
        profile = pr;
        world = w;
        tick = nowTick;
        kpx = s.px;
        kpy = s.py;
        kpz = s.pz;
        kvx = s.vx;
        kvy = s.vy;
        kvz = s.vz;
    }

    void clear() {
        valid = false;
        active = false;
        profile = null;
        world = null;
        trajectory.reset();
    }
}
