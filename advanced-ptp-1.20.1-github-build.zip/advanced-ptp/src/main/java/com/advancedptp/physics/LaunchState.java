package com.advancedptp.physics;

/** Mutable launch position + velocity, filled by {@link LaunchCalculator}. */
public final class LaunchState {
    public double px, py, pz;
    public double vx, vy, vz;
}
