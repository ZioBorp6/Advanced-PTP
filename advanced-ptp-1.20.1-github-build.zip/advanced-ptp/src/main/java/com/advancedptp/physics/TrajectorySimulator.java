package com.advancedptp.physics;

import com.advancedptp.projectile.LaunchProfile;
import com.advancedptp.projectile.LaunchStyle;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.function.Predicate;

/**
 * Steps a projectile through the world with the same per-tick order vanilla uses:
 * collision sweep, move, drag, gravity. Item drops use gravity-first ordering like ItemEntity.
 */
public final class TrajectorySimulator {
    private static Entity ignored;
    private static final Predicate<Entity> HITTABLE =
        e -> e != ignored && !e.isSpectator() && e.isAlive() && e.canHit();

    private TrajectorySimulator() {}

    public static void simulate(ClientWorld world, ClientPlayerEntity player, LaunchProfile pr,
                                LaunchState s, Trajectory out) {
        out.reset();
        ignored = player;

        double px = s.px, py = s.py, pz = s.pz;
        double vx = s.vx, vy = s.vy, vz = s.vz;
        boolean itemDrop = pr.style() == LaunchStyle.ITEM_DROP;
        int maxSteps = Math.min(pr.maxSteps(), Trajectory.MAX_POINTS - 2);
        int bottom = world.getBottomY() - 16;

        out.add(px, py, pz);

        for (int step = 0; step < maxSteps; step++) {
            if (itemDrop) {
                vy -= pr.gravity();
            }

            Vec3d cur = new Vec3d(px, py, pz);
            Vec3d next = new Vec3d(px + vx, py + vy, pz + vz);

            // Stop at the edge of the loaded world instead of reading empty chunks.
            if (!world.getChunkManager().isChunkLoaded(MathHelper.floor(next.x) >> 4, MathHelper.floor(next.z) >> 4)) {
                break;
            }

            BlockHitResult blockHit = world.raycast(new RaycastContext(
                cur, next, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
            boolean hitBlock = blockHit.getType() != HitResult.Type.MISS;
            Vec3d segmentEnd = hitBlock ? blockHit.getPos() : next;

            if (pr.hitsEntities()) {
                EntityHitResult entityHit = ProjectileUtil.getEntityCollision(
                    world, player, cur, segmentEnd, new Box(cur, next).expand(1.0), HITTABLE);
                if (entityHit != null) {
                    Vec3d hp = entityHit.getPos();
                    out.add(hp.x, hp.y, hp.z);
                    out.hitType = Trajectory.HitType.ENTITY;
                    out.hitEntity = entityHit.getEntity();
                    out.hitPos = hp;
                    return;
                }
            }

            if (hitBlock) {
                Vec3d hp = blockHit.getPos();
                out.add(hp.x, hp.y, hp.z);
                out.hitType = Trajectory.HitType.BLOCK;
                out.hitPos = hp;
                out.hitBlock = blockHit.getBlockPos();
                out.hitSide = blockHit.getSide();
                return;
            }

            px = next.x;
            py = next.y;
            pz = next.z;
            out.add(px, py, pz);

            if (py < bottom) {
                return;
            }

            boolean inWater = world.getFluidState(BlockPos.ofFloored(px, py, pz)).isIn(FluidTags.WATER);
            if (inWater && pr.stopsInWater()) {
                out.hitType = Trajectory.HitType.WATER;
                out.hitPos = next;
                return;
            }

            double drag = inWater ? pr.waterDrag() : pr.drag();
            vx *= drag;
            vy *= drag;
            vz *= drag;
            if (!itemDrop) {
                vy -= pr.gravity();
            }
        }
    }
}
