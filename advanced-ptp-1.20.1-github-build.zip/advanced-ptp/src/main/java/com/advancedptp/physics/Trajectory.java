package com.advancedptp.physics;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/** Re-usable result buffer for one simulated flight path (no allocation per simulation). */
public final class Trajectory {
    public static final int MAX_POINTS = 640;

    public enum HitType { NONE, BLOCK, ENTITY, WATER }

    public final double[] x = new double[MAX_POINTS];
    public final double[] y = new double[MAX_POINTS];
    public final double[] z = new double[MAX_POINTS];
    public int count;

    public HitType hitType = HitType.NONE;
    public Vec3d hitPos = Vec3d.ZERO;
    public BlockPos hitBlock = BlockPos.ORIGIN;
    public Direction hitSide = Direction.UP;
    public Entity hitEntity;

    public void reset() {
        count = 0;
        hitType = HitType.NONE;
        hitPos = Vec3d.ZERO;
        hitEntity = null;
    }

    public void add(double px, double py, double pz) {
        if (count < MAX_POINTS) {
            x[count] = px;
            y[count] = py;
            z[count] = pz;
            count++;
        }
    }
}
