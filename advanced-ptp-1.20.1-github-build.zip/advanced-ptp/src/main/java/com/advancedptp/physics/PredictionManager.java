package com.advancedptp.physics;

import com.advancedptp.config.PtpConfig;
import com.advancedptp.projectile.LaunchProfile;
import com.advancedptp.projectile.ProjectileProfiles;
import com.advancedptp.projectile.ProjectileResolver;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;

/** Decides which predictions are visible this frame and recomputes them only when inputs change. */
public final class PredictionManager {
    /** Results are also refreshed this often so world edits (placed/broken blocks) show up. */
    private static final int MAX_AGE_TICKS = 4;

    public static final PredictionSlot MAIN = new PredictionSlot();
    public static final PredictionSlot OFF = new PredictionSlot();
    public static final PredictionSlot DROP = new PredictionSlot();

    private static final LaunchState STATE = new LaunchState();
    private static int ticks;

    private PredictionManager() {}

    public static void tick() {
        ticks++;
    }

    /** Called when leaving a world; releases entity/world references. */
    public static void clear() {
        MAIN.clear();
        OFF.clear();
        DROP.clear();
    }

    public static void update(MinecraftClient mc, float tickDelta) {
        PtpConfig cfg = PtpConfig.get();
        ClientPlayerEntity player = mc.player;
        ClientWorld world = mc.world;

        LaunchProfile main = cfg.mainHandEnabled ? ProjectileResolver.resolve(player, Hand.MAIN_HAND, cfg) : null;
        LaunchProfile off = cfg.offHandEnabled ? ProjectileResolver.resolve(player, Hand.OFF_HAND, cfg) : null;
        refresh(MAIN, main, player, world, tickDelta);
        refresh(OFF, off, player, world, tickDelta);

        LaunchProfile drop = null;
        if (cfg.dropTrajectoryEnabled && !MAIN.active && !OFF.active) {
            ItemStack held = player.getMainHandStack();
            if (!held.isEmpty()) {
                drop = ProjectileProfiles.ITEM_DROP;
            }
        }
        refresh(DROP, drop, player, world, tickDelta);
    }

    private static void refresh(PredictionSlot slot, LaunchProfile profile, ClientPlayerEntity player,
                                ClientWorld world, float tickDelta) {
        if (profile == null) {
            slot.active = false;
            return;
        }
        LaunchCalculator.compute(profile, player, tickDelta, STATE);
        if (!slot.isFresh(profile, STATE, world, ticks, MAX_AGE_TICKS)) {
            TrajectorySimulator.simulate(world, player, profile, STATE, slot.trajectory);
            slot.store(profile, STATE, world, ticks);
        }
        slot.active = true;
    }
}
