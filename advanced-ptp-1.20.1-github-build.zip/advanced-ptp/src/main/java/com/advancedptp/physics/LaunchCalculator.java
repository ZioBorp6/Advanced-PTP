package com.advancedptp.physics;

import com.advancedptp.projectile.LaunchProfile;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Reproduces how vanilla 1.20.1 positions and aims each projectile type when it is launched. */
public final class LaunchCalculator {
    private static final float DEG = 0.017453292F;

    private LaunchCalculator() {}

    public static void compute(LaunchProfile pr, ClientPlayerEntity p, float tickDelta, LaunchState s) {
        Vec3d pos = p.getLerpedPos(tickDelta);
        float yaw = p.getYaw(tickDelta);
        float pitch = p.getPitch(tickDelta);
        double eye = pos.y + p.getEyeHeight(p.getPose());

        switch (pr.style()) {
            case BOBBER -> {
                float h = MathHelper.cos(-yaw * DEG - (float) Math.PI);
                float i = MathHelper.sin(-yaw * DEG - (float) Math.PI);
                float j = -MathHelper.cos(-pitch * DEG);
                float k = MathHelper.sin(-pitch * DEG);
                s.px = pos.x - i * 0.3;
                s.py = eye;
                s.pz = pos.z - h * 0.3;
                double dx = -i;
                double dy = MathHelper.clamp(-(k / j), -5.0f, 5.0f);
                double dz = -h;
                double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
                // Vanilla multiplies by 0.6/len plus a random value with mean 0.5.
                double m = 0.6 / len + 0.5;
                s.vx = dx * m;
                s.vy = dy * m;
                s.vz = dz * m;
            }
            case ITEM_DROP -> {
                float sp = MathHelper.sin(pitch * DEG);
                float cp = MathHelper.cos(pitch * DEG);
                float sy = MathHelper.sin(yaw * DEG);
                float cy = MathHelper.cos(yaw * DEG);
                s.px = pos.x;
                s.py = eye - 0.3;
                s.pz = pos.z;
                // Random spread in vanilla has mean zero; the aim is deterministic.
                s.vx = -sy * cp * 0.3f;
                s.vy = -sp * 0.3f + 0.1f;
                s.vz = cy * cp * 0.3f;
            }
            default -> {
                // PersistentProjectileEntity / ThrownEntity constructor + ProjectileEntity.setVelocity
                s.px = pos.x;
                s.py = eye - 0.1;
                s.pz = pos.z;
                double dx = -MathHelper.sin(yaw * DEG) * MathHelper.cos(pitch * DEG);
                double dy = -MathHelper.sin((pitch + pr.pitchOffset()) * DEG);
                double dz = MathHelper.cos(yaw * DEG) * MathHelper.cos(pitch * DEG);
                double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
                s.vx = dx / len * pr.speed();
                s.vy = dy / len * pr.speed();
                s.vz = dz / len * pr.speed();
                if (pr.style() == com.advancedptp.projectile.LaunchStyle.STANDARD) {
                    Vec3d v = p.getVelocity();
                    s.vx += v.x;
                    s.vy += p.isOnGround() ? 0.0 : v.y;
                    s.vz += v.z;
                }
            }
        }
    }
}
