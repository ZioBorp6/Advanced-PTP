package com.advancedptp.projectile;

import com.advancedptp.config.PtpConfig;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ArrowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/** Maps a held item stack to the launch profile it would produce right now (or null). */
public final class ProjectileResolver {
    private static LaunchProfile cachedArrow;

    private ProjectileResolver() {}

    public static LaunchProfile resolve(ClientPlayerEntity player, Hand hand, PtpConfig cfg) {
        ItemStack stack = player.getStackInHand(hand);
        if (stack.isEmpty()) {
            return null;
        }

        LaunchProfile profile = null;
        if (stack.isOf(Items.BOW)) {
            profile = bow(player, hand);
        } else if (stack.isOf(Items.CROSSBOW)) {
            profile = crossbow(stack);
        } else if (stack.isOf(Items.TRIDENT)) {
            // Riptide tridents launch the player instead of throwing.
            if (EnchantmentHelper.getRiptide(stack) <= 0) {
                profile = ProjectileProfiles.TRIDENT;
            }
        } else if (stack.isOf(Items.SNOWBALL)) {
            profile = ProjectileProfiles.SNOWBALL;
        } else if (stack.isOf(Items.EGG)) {
            profile = ProjectileProfiles.EGG;
        } else if (stack.isOf(Items.ENDER_PEARL)) {
            profile = ProjectileProfiles.ENDER_PEARL;
        } else if (stack.isOf(Items.EXPERIENCE_BOTTLE)) {
            profile = ProjectileProfiles.EXPERIENCE_BOTTLE;
        } else if (stack.isOf(Items.SPLASH_POTION)) {
            profile = ProjectileProfiles.SPLASH_POTION;
        } else if (stack.isOf(Items.LINGERING_POTION)) {
            profile = ProjectileProfiles.LINGERING_POTION;
        } else if (stack.isOf(Items.FISHING_ROD)) {
            // Only preview the cast; once a bobber is out the rod reels it in instead.
            if (player.fishHook == null) {
                profile = ProjectileProfiles.FISHING_BOBBER;
            }
        }

        if (profile == null || !cfg.isKindEnabled(profile.kind())) {
            return null;
        }
        return profile;
    }

    private static LaunchProfile bow(ClientPlayerEntity player, Hand hand) {
        if (!player.isUsingItem() || player.getActiveHand() != hand) {
            return null;
        }
        // Same curve as BowItem.getPullProgress.
        float t = player.getItemUseTime() / 20.0f;
        float pull = Math.min(1.0f, (t * t + t * 2.0f) / 3.0f);
        if (pull < 0.1f) {
            return null; // too weak to fire
        }
        ItemStack ammo = findArrow(player);
        if (ammo.isEmpty() && !player.getAbilities().creativeMode) {
            return null;
        }
        ProjectileKind kind = ammo.isOf(Items.SPECTRAL_ARROW) ? ProjectileKind.SPECTRAL_ARROW : ProjectileKind.ARROW;
        return arrow(kind, LaunchStyle.STANDARD, pull * 3.0);
    }

    private static LaunchProfile crossbow(ItemStack stack) {
        if (!CrossbowItem.isCharged(stack) || CrossbowItem.hasProjectile(stack, Items.FIREWORK_ROCKET)) {
            return null;
        }
        ProjectileKind kind = CrossbowItem.hasProjectile(stack, Items.SPECTRAL_ARROW)
            ? ProjectileKind.SPECTRAL_ARROW : ProjectileKind.ARROW;
        return arrow(kind, LaunchStyle.NO_INHERIT, 3.15);
    }

    /** Re-uses the last arrow profile while the speed does not change to avoid per-frame allocation. */
    private static LaunchProfile arrow(ProjectileKind kind, LaunchStyle style, double speed) {
        LaunchProfile c = cachedArrow;
        if (c != null && c.kind() == kind && c.style() == style && c.speed() == speed) {
            return c;
        }
        cachedArrow = ProjectileProfiles.arrow(kind, style, speed);
        return cachedArrow;
    }

    private static ItemStack findArrow(ClientPlayerEntity player) {
        ItemStack off = player.getOffHandStack();
        if (off.getItem() instanceof ArrowItem) {
            return off;
        }
        ItemStack main = player.getMainHandStack();
        if (main.getItem() instanceof ArrowItem) {
            return main;
        }
        PlayerInventory inv = player.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.getItem() instanceof ArrowItem) {
                return s;
            }
        }
        return ItemStack.EMPTY;
    }
}
