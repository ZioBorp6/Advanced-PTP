package com.advancedptp.projectile;

public enum LaunchStyle {
    /** Aim vector from yaw/pitch; the shooter's own velocity is added (bows, throwables, tridents). */
    STANDARD,
    /** Aim vector from yaw/pitch, shooter velocity NOT added (crossbows). */
    NO_INHERIT,
    /** Fishing bobber specific launch maths. */
    BOBBER,
    /** Player dropping an item stack with Q. */
    ITEM_DROP
}
