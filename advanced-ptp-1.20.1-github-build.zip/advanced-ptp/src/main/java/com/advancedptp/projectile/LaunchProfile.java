package com.advancedptp.projectile;

/**
 * Immutable description of how a projectile is launched and moves each tick (Minecraft 1.20.1 values).
 *
 * @param speed       launch speed in blocks/tick
 * @param pitchOffset degrees added to the pitch of the launch vector (potions / XP bottles use -20)
 * @param gravity     downward acceleration per tick
 * @param drag        velocity multiplier per tick in air
 * @param waterDrag   velocity multiplier per tick in water
 */
public record LaunchProfile(ProjectileKind kind, LaunchStyle style, double speed, float pitchOffset,
                            double gravity, double drag, double waterDrag,
                            boolean hitsEntities, boolean stopsInWater, int maxSteps) {
}
