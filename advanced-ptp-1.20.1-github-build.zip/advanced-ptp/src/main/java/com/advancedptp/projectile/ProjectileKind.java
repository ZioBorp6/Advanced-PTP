package com.advancedptp.projectile;

import java.util.Locale;

public enum ProjectileKind {
    ARROW, SPECTRAL_ARROW, TRIDENT, SNOWBALL, EGG, ENDER_PEARL,
    EXPERIENCE_BOTTLE, SPLASH_POTION, LINGERING_POTION, FISHING_BOBBER,
    /** Not a projectile item; used for the item-drop preview (has its own keybind/toggle). */
    DROPPED_ITEM;

    /** Kinds that get a per-item toggle in the settings screen. */
    public static final ProjectileKind[] TOGGLEABLE = {
        ARROW, SPECTRAL_ARROW, TRIDENT, SNOWBALL, EGG, ENDER_PEARL,
        EXPERIENCE_BOTTLE, SPLASH_POTION, LINGERING_POTION, FISHING_BOBBER
    };

    public String translationKey() {
        return "advancedptp.item." + name().toLowerCase(Locale.ROOT);
    }
}
