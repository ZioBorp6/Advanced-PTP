package com.advancedptp.projectile;

/** Physics constants for each supported projectile, taken from the 1.20.1 entity classes. */
public final class ProjectileProfiles {
    private ProjectileProfiles() {}

    public static final LaunchProfile SNOWBALL = thrown(ProjectileKind.SNOWBALL, 1.5, 0.0f, 0.03);
    public static final LaunchProfile EGG = thrown(ProjectileKind.EGG, 1.5, 0.0f, 0.03);
    public static final LaunchProfile ENDER_PEARL = thrown(ProjectileKind.ENDER_PEARL, 1.5, 0.0f, 0.03);
    public static final LaunchProfile EXPERIENCE_BOTTLE = thrown(ProjectileKind.EXPERIENCE_BOTTLE, 0.7, -20.0f, 0.07);
    public static final LaunchProfile SPLASH_POTION = thrown(ProjectileKind.SPLASH_POTION, 0.5, -20.0f, 0.05);
    public static final LaunchProfile LINGERING_POTION = thrown(ProjectileKind.LINGERING_POTION, 0.5, -20.0f, 0.05);

    public static final LaunchProfile TRIDENT =
        new LaunchProfile(ProjectileKind.TRIDENT, LaunchStyle.STANDARD, 2.5, 0.0f, 0.05, 0.99, 0.99, true, false, 300);

    public static final LaunchProfile FISHING_BOBBER =
        new LaunchProfile(ProjectileKind.FISHING_BOBBER, LaunchStyle.BOBBER, 0.0, 0.0f, 0.03, 0.92, 0.92, true, true, 160);

    public static final LaunchProfile ITEM_DROP =
        new LaunchProfile(ProjectileKind.DROPPED_ITEM, LaunchStyle.ITEM_DROP, 0.0, 0.0f, 0.04, 0.98, 0.98, false, false, 120);

    private static LaunchProfile thrown(ProjectileKind kind, double speed, float pitchOffset, double gravity) {
        return new LaunchProfile(kind, LaunchStyle.STANDARD, speed, pitchOffset, gravity, 0.99, 0.8, true, false, 300);
    }

    public static LaunchProfile arrow(ProjectileKind kind, LaunchStyle style, double speed) {
        return new LaunchProfile(kind, style, speed, 0.0f, 0.05, 0.99, 0.6, true, false, 300);
    }
}
