package com.advancedptp.config;

import java.util.Locale;

public enum TrajectoryColor {
    RED(255, 40, 40),
    GREEN(40, 235, 60),
    BLUE(70, 110, 255),
    YELLOW(255, 235, 40),
    CYAN(40, 230, 235),
    MAGENTA(255, 50, 230),
    WHITE(255, 255, 255),
    PURPLE(155, 60, 235);

    public final int r, g, b;

    TrajectoryColor(int r, int g, int b) {
        this.r = r;
        this.g = g;
        this.b = b;
    }

    public String translationKey() {
        return "advancedptp.color." + name().toLowerCase(Locale.ROOT);
    }
}
