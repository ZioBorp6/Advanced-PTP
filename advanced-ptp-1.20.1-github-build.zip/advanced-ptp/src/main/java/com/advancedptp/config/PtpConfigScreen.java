package com.advancedptp.config;

import com.advancedptp.projectile.ProjectileKind;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.IntConsumer;
import java.util.function.IntFunction;
import java.util.function.Supplier;

/** Tabbed settings screen; opened from Mod Menu. Every change is written to disk immediately. */
public final class PtpConfigScreen extends Screen {
    private static final String[] TABS = {"general", "trajectory", "targets", "items"};
    private static final int ROW = 24;

    private final Screen parent;
    private final int tab;

    public PtpConfigScreen(Screen parent) {
        this(parent, 0);
    }

    private PtpConfigScreen(Screen parent, int tab) {
        super(Text.translatable("advancedptp.config.title"));
        this.parent = parent;
        this.tab = tab;
    }

    @Override
    protected void init() {
        PtpConfig c = PtpConfig.get();
        int cx = width / 2;

        int tabW = 90;
        int x0 = cx - (TABS.length * (tabW + 4) - 4) / 2;
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            ButtonWidget b = ButtonWidget.builder(Text.translatable("advancedptp.tab." + TABS[i]),
                    btn -> client.setScreen(new PtpConfigScreen(parent, idx)))
                .dimensions(x0 + i * (tabW + 4), 24, tabW, 20).build();
            b.active = i != tab;
            addDrawableChild(b);
        }

        int w = 240;
        int x = cx - w / 2;
        int y = 54;
        switch (tab) {
            case 0 -> {
                y = toggle(x, y, w, "enabled", () -> c.enabled, v -> c.enabled = v);
                y = toggle(x, y, w, "main_hand", () -> c.mainHandEnabled, v -> c.mainHandEnabled = v);
                y = toggle(x, y, w, "off_hand", () -> c.offHandEnabled, v -> c.offHandEnabled = v);
                y = toggle(x, y, w, "drop", () -> c.dropTrajectoryEnabled, v -> c.dropTrajectoryEnabled = v);
                toggle(x, y, w, "see_through", () -> c.seeThroughBlocks, v -> c.seeThroughBlocks = v);
            }
            case 1 -> {
                y = cycle(x, y, w, "color", TrajectoryColor.values(), () -> c.trajectoryColor,
                    v -> c.trajectoryColor = v, TrajectoryColor::translationKey);
                y = cycle(x, y, w, "style", LineStyle.values(), () -> c.lineStyle,
                    v -> c.lineStyle = v, LineStyle::translationKey);
                y = slider(x, y, w, "opacity", 0, 100, c.trajectoryOpacity, v -> c.trajectoryOpacity = v, v -> v + "%");
                slider(x, y, w, "thickness", 10, 80, Math.round(c.lineThickness * 10),
                    v -> c.lineThickness = v / 10.0f, v -> String.format(Locale.ROOT, "%.1f", v / 10.0));
            }
            case 2 -> {
                y = toggle(x, y, w, "outline", () -> c.outliningEnabled, v -> c.outliningEnabled = v);
                y = cycle(x, y, w, "outline_color", TrajectoryColor.values(), () -> c.outlineColor,
                    v -> c.outlineColor = v, TrajectoryColor::translationKey);
                y = slider(x, y, w, "outline_opacity", 0, 100, c.outlineOpacity, v -> c.outlineOpacity = v, v -> v + "%");
                y = toggle(x, y, w, "highlight", () -> c.highlightingEnabled, v -> c.highlightingEnabled = v);
                y = cycle(x, y, w, "highlight_color", TrajectoryColor.values(), () -> c.highlightColor,
                    v -> c.highlightColor = v, TrajectoryColor::translationKey);
                slider(x, y, w, "highlight_opacity", 0, 100, c.highlightOpacity, v -> c.highlightOpacity = v, v -> v + "%");
            }
            default -> {
                ProjectileKind[] kinds = ProjectileKind.TOGGLEABLE;
                for (int i = 0; i < kinds.length; i++) {
                    final ProjectileKind k = kinds[i];
                    int bx = (i % 2 == 0) ? cx - 155 : cx + 5;
                    int by = 54 + (i / 2) * ROW;
                    addDrawableChild(ButtonWidget.builder(itemLabel(k, c.isKindEnabled(k)), b -> {
                        c.setKindEnabled(k, !c.isKindEnabled(k));
                        b.setMessage(itemLabel(k, c.isKindEnabled(k)));
                        PtpConfig.save();
                    }).dimensions(bx, by, 150, 20).build());
                }
            }
        }

        addDrawableChild(ButtonWidget.builder(ScreenTexts.DONE, b -> close())
            .dimensions(cx - 100, height - 28, 200, 20).build());
    }

    private static Text itemLabel(ProjectileKind k, boolean on) {
        return Text.translatable(k.translationKey()).append(Text.literal(": ")).append(onOff(on));
    }

    private static Text onOff(boolean on) {
        return Text.translatable(on ? "options.on" : "options.off").formatted(on ? Formatting.GREEN : Formatting.RED);
    }

    private static Text label(String key, Text value) {
        return Text.translatable("advancedptp.option." + key).append(Text.literal(": ")).append(value);
    }

    private int toggle(int x, int y, int w, String key, BooleanSupplier get, Consumer<Boolean> set) {
        addDrawableChild(ButtonWidget.builder(label(key, onOff(get.getAsBoolean())), b -> {
            set.accept(!get.getAsBoolean());
            b.setMessage(label(key, onOff(get.getAsBoolean())));
            PtpConfig.save();
        }).dimensions(x, y, w, 20).build());
        return y + ROW;
    }

    private <E extends Enum<E>> int cycle(int x, int y, int w, String key, E[] values, Supplier<E> get,
                                          Consumer<E> set, Function<E, String> tr) {
        addDrawableChild(ButtonWidget.builder(label(key, Text.translatable(tr.apply(get.get()))), b -> {
            set.accept(values[(get.get().ordinal() + 1) % values.length]);
            b.setMessage(label(key, Text.translatable(tr.apply(get.get()))));
            PtpConfig.save();
        }).dimensions(x, y, w, 20).build());
        return y + ROW;
    }

    private int slider(int x, int y, int w, String key, int min, int max, int initial,
                       IntConsumer set, IntFunction<String> fmt) {
        addDrawableChild(new IntSlider(x, y, w, key, min, max, initial, set, fmt));
        return y + ROW;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 8, 0xFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void removed() {
        PtpConfig.save();
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    private static final class IntSlider extends SliderWidget {
        private final String key;
        private final int min, max;
        private final IntConsumer onChange;
        private final IntFunction<String> fmt;

        IntSlider(int x, int y, int w, String key, int min, int max, int initial,
                  IntConsumer onChange, IntFunction<String> fmt) {
            super(x, y, w, 20, Text.empty(), (initial - min) / (double) (max - min));
            this.key = key;
            this.min = min;
            this.max = max;
            this.onChange = onChange;
            this.fmt = fmt;
            updateMessage();
        }

        private int current() {
            return min + (int) Math.round(value * (max - min));
        }

        @Override
        protected void updateMessage() {
            setMessage(label(key, Text.literal(fmt.apply(current()))));
        }

        @Override
        protected void applyValue() {
            onChange.accept(current());
        }
    }
}
