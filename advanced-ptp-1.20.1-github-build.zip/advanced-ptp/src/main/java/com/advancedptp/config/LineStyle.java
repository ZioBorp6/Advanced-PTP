package com.advancedptp.config;

import java.util.Locale;

public enum LineStyle {
    SOLID(Double.POSITIVE_INFINITY, 0.0),
    DASHED(0.45, 0.30),
    DOTTED(0.05, 0.22);

    /** Length in blocks of a drawn piece / a gap. */
    public final double on, off;

    LineStyle(double on, double off) {
        this.on = on;
        this.off = off;
    }

    public String translationKey() {
        return "advancedptp.style." + name().toLowerCase(Locale.ROOT);
    }
}
