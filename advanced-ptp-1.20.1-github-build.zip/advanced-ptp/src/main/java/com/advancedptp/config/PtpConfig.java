package com.advancedptp.config;

import com.advancedptp.AdvancedPtpClient;
import com.advancedptp.projectile.ProjectileKind;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/** Persistent client configuration, stored as config/advancedptp.json. */
public final class PtpConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static PtpConfig instance = new PtpConfig();

    public boolean enabled = true;
    public boolean mainHandEnabled = true;
    public boolean offHandEnabled = true;
    public boolean dropTrajectoryEnabled = false;
    public boolean seeThroughBlocks = false;

    public TrajectoryColor trajectoryColor = TrajectoryColor.CYAN;
    public LineStyle lineStyle = LineStyle.SOLID;
    public int trajectoryOpacity = 85;
    /** Line width in pixels. */
    public float lineThickness = 2.5f;

    public boolean outliningEnabled = true;
    public TrajectoryColor outlineColor = TrajectoryColor.YELLOW;
    public int outlineOpacity = 90;

    public boolean highlightingEnabled = true;
    public TrajectoryColor highlightColor = TrajectoryColor.RED;
    public int highlightOpacity = 35;

    public Map<String, Boolean> itemToggles = new HashMap<>();

    public static PtpConfig get() {
        return instance;
    }

    public boolean isKindEnabled(ProjectileKind kind) {
        return itemToggles.getOrDefault(kind.name(), Boolean.TRUE);
    }

    public void setKindEnabled(ProjectileKind kind, boolean value) {
        itemToggles.put(kind.name(), value);
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("advancedptp.json");
    }

    public static void load() {
        Path p = path();
        if (Files.exists(p)) {
            try (Reader r = Files.newBufferedReader(p, StandardCharsets.UTF_8)) {
                PtpConfig loaded = GSON.fromJson(r, PtpConfig.class);
                if (loaded != null) {
                    instance = loaded;
                }
            } catch (Exception e) {
                AdvancedPtpClient.LOGGER.warn("Could not read config, using defaults", e);
            }
        }
        instance.sanitize();
        save();
    }

    public static void save() {
        Path p = path();
        try {
            Files.createDirectories(p.getParent());
            try (Writer w = Files.newBufferedWriter(p, StandardCharsets.UTF_8)) {
                GSON.toJson(instance, w);
            }
        } catch (IOException e) {
            AdvancedPtpClient.LOGGER.warn("Could not save config", e);
        }
    }

    /** Repairs null enums / out-of-range numbers coming from a hand-edited file. */
    private void sanitize() {
        if (trajectoryColor == null) trajectoryColor = TrajectoryColor.CYAN;
        if (outlineColor == null) outlineColor = TrajectoryColor.YELLOW;
        if (highlightColor == null) highlightColor = TrajectoryColor.RED;
        if (lineStyle == null) lineStyle = LineStyle.SOLID;
        if (itemToggles == null) itemToggles = new HashMap<>();
        trajectoryOpacity = Math.max(0, Math.min(100, trajectoryOpacity));
        outlineOpacity = Math.max(0, Math.min(100, outlineOpacity));
        highlightOpacity = Math.max(0, Math.min(100, highlightOpacity));
        lineThickness = Math.max(1.0f, Math.min(8.0f, lineThickness));
    }
}
