package com.advancedptp;

import com.advancedptp.compatibility.ModCompat;
import com.advancedptp.config.PtpConfig;
import com.advancedptp.keybind.Keybinds;
import com.advancedptp.physics.PredictionManager;
import com.advancedptp.rendering.TrajectoryRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class AdvancedPtpClient implements ClientModInitializer {
    public static final String MOD_ID = "advancedptp";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        PtpConfig.load();
        Keybinds.register();
        ModCompat.init();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            Keybinds.tick(client);
            PredictionManager.tick();
        });
        WorldRenderEvents.LAST.register(TrajectoryRenderer::render);

        // Drop every cached world/entity reference when leaving a world or closing the game.
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> PredictionManager.clear());
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            PredictionManager.clear();
            PtpConfig.save();
        });
        LOGGER.info("Advanced Projectile Trajectory Prediction loaded");
    }
}
