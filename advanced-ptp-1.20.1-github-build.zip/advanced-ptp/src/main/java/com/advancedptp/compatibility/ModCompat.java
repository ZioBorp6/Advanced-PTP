package com.advancedptp.compatibility;

import com.advancedptp.AdvancedPtpClient;
import net.fabricmc.loader.api.FabricLoader;

/** Soft-dependency helpers. Nothing here may reference classes of optional mods directly. */
public final class ModCompat {
    private static boolean modMenu;

    private ModCompat() {}

    public static void init() {
        modMenu = isLoaded("modmenu");
        AdvancedPtpClient.LOGGER.info("Mod Menu integration {}", modMenu ? "available" : "not installed");
    }

    public static boolean hasModMenu() {
        return modMenu;
    }

    public static boolean isLoaded(String id) {
        return FabricLoader.getInstance().isModLoaded(id);
    }
}
