package com.advancedptp.util;

import com.advancedptp.config.TrajectoryColor;

public final class ColorUtil {
    private ColorUtil() {}

    /** Packs a palette colour and a 0-100 opacity percentage into ARGB. */
    public static int argb(TrajectoryColor color, int opacityPercent) {
        int a = Math.round(255f * Math.max(0, Math.min(100, opacityPercent)) / 100f);
        return (a << 24) | (color.r << 16) | (color.g << 8) | color.b;
    }
}
