# Advanced Projectile Trajectory Prediction

Client-side Fabric mod for **Minecraft 1.20.1** (Java 17, Yarn mappings). It draws the predicted flight path of
projectiles before you throw or shoot them. Works in single-player and on any server (nothing is sent to the server).

## Features
- Arrows, spectral arrows (bow and loaded crossbow), tridents, snowballs, eggs, ender pearls, XP bottles,
  splash and lingering potions, fishing bobbers, plus an optional item-drop preview.
- Vanilla 1.20.1 launch maths and per-tick physics (gravity, air/water drag, shooter velocity, bow charge).
- Block and entity collision; the line stops at the predicted impact and an impact marker is drawn.
- Solid / dashed / dotted lines, thickness 1-8 px, opacity, 8 colours, optional "show through blocks".
- Target outlining (entity box) and target highlighting (entity box or hit block face), each with colour + opacity.
- Independent main-hand and offhand predictions.
- Config screen via Mod Menu (General / Trajectory / Targets / Items tabs), saved automatically to
  `config/advancedptp.json`.
- Keybinds (unbound by default, set them in Options > Controls > Trajectory Prediction):
  toggle all, toggle outlining, toggle highlighting, toggle item-drop trajectory.

## Installation (players)
1. Install Fabric Loader 0.14.21+ for Minecraft 1.20.1 and Fabric API 0.92.2+1.20.1 (or newer 1.20.1 build).
2. Optional: Mod Menu 7.x for the settings button.
3. Put `advanced-ptp-1.0.0.jar` in your `mods` folder.

## Building
Requirements: JDK 17+ and internet access (Gradle downloads Minecraft, Yarn and Fabric Loom).

```
gradle wrapper --gradle-version 8.5   # once, only if gradlew / gradle-wrapper.jar are missing
./gradlew build                       # Windows: gradlew.bat build
```
The mod jar is written to `build/libs/advanced-ptp-1.0.0.jar` (the `-sources` jar is not the one to install).
Use `./gradlew runClient` to test in a dev client.

## Project layout
`projectile` (item -> launch profile) · `physics` (launch maths, simulator, cache) · `rendering` (world-space lines/quads)
· `config` (settings + screen) · `keybind` · `compatibility` (Mod Menu) · `util`.

## Notes
- Prediction ignores random arrow spread (divergence), which has zero mean; crossbow multishot is not previewed.
- Predictions are cached and only re-simulated when position, aim, velocity, charge or the held item changes,
  or every 4 ticks so block changes are picked up. Caches are cleared on disconnect; the mod holds no GPU resources.

## Cloud build with GitHub Actions

This project includes `.github/workflows/build.yml`. Upload the project to a GitHub repository, then open **Actions** and run **Build Advanced PTP (Minecraft 1.20.1)**. The workflow installs Java 17 and Gradle 8.5, downloads the Fabric/Minecraft dependencies, builds the mod, and uploads `advanced-ptp-1.0.0.jar` as an artifact. Open the successful workflow run and download the artifact named `advanced-ptp-1.20.1`.
